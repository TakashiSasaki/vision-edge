# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: integration.spec.ts >> asset diagnostic selfie-segmenter
- Location: e2e-real-sdk/integration.spec.ts:103:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]: VisionStudio AI
    - generic [ref=e12]:
      - generic [ref=e13]:
        - generic [ref=e14]: "モデル:"
        - combobox "モデル" [ref=e15] [cursor=pointer]:
          - option "Selfie Segmenter" [selected]
          - option "EfficientDet-Lite0"
          - option "YOLO-seg（未実装・選択不可）" [disabled]
          - option "SegFormer（未実装・選択不可）" [disabled]
      - generic "バックエンド状態" [ref=e20]: バックエンド未準備
    - generic [ref=e21]:
      - button "音声読み上げ OFF (クリックで有効化)" [ref=e22]
      - button "仕様" [ref=e27]
      - button "カメラ開始" [active] [ref=e32]
  - status [ref=e37]: モデル未準備
  - main [ref=e38]:
    - generic [ref=e40]:
      - generic [ref=e41] [cursor=pointer]
      - generic [ref=e42]:
        - heading "Webカメラ待機中" [level=3] [ref=e47]
        - paragraph [ref=e48]: カメラを開始し、モデルの準備が完了すると推論結果を取得します。
        - button "カメラを開始する" [ref=e49]
      - generic:
        - text: Selfie Segmenterカメラ停止中停止中
        - generic "推論FPS": "推論: 未計測"
        - generic "描画FPS": "描画: 未計測"
        - generic "フレーム処理時間": "フレーム処理: 未計測"
      - group "パイプライン計測詳細" [ref=e54]:
        - generic "計測詳細 (JS wall time)" [ref=e55] [cursor=pointer]
    - generic [ref=e57]:
      - generic [ref=e58]:
        - button "認識物体 （未取得）" [ref=e59]
        - button "音声・設定" [ref=e65]
      - generic [ref=e70]:
        - generic [ref=e71]:
          - generic [ref=e72]: 認識結果は未取得です
          - generic [ref=e73]: タップで個別発話
        - generic [ref=e74]:
          - paragraph [ref=e79]: モデルとカメラの準備後、推論結果を表示します
          - paragraph [ref=e80]: 未取得は正常な空検出を意味しません
```

# Test source

```ts
  12  |       await installCamera(context, input, model === 'mediapipe' ? 'coffee.png' : 'astronaut.png');
  13  |       const requests = await routeAssets(context);
  14  |       const errors: string[] = []; page.on('pageerror', e => errors.push(e.message));
  15  |       try {
  16  |         await page.goto('/');
  17  |         if (model === 'mediapipe') await page.getByRole('banner').getByRole('combobox').selectOption(model);
  18  |         await ready(page);
  19  |         await expect.poll(() => page.evaluate(model => window.__realSdkProbe.processed.filter(r => r.model === model && r.status === 'ready').length, model)).toBeGreaterThanOrEqual(4);
  20  |         const positive = await page.evaluate(() => ({ raw: window.__realSdkProbe.raw, processed: window.__realSdkProbe.processed, draws: window.__realSdkProbe.draws }));
  21  |         const raws = positive.raw.filter(r => r.model === model && !r.error);
  22  |         expect(raws.length).toBeGreaterThanOrEqual(4);
  23  |         expect(raws.every(r => r.input === input)).toBe(true);
  24  |         const expected = model === 'mediapipe' ? 'cup' : 'person';
  25  |         await expect.poll(() => page.evaluate(({ model, expected }) => window.__realSdkProbe.processed.some(r => r.model === model && r.status === 'ready' && r.objects.some(obj => obj.label === expected) && window.__realSdkProbe.draws.some(d => d.id === r.id)), { model, expected })).toBe(true);
  26  |         const result = await page.evaluate(({ model, expected }) => window.__realSdkProbe.processed.find(r => r.model === model && r.status === 'ready' && r.objects.some(obj => obj.label === expected) && window.__realSdkProbe.draws.some(d => d.id === r.id)), { model, expected });
  27  |         expect(result, `semantic positive ${expected}`).toBeTruthy();
  28  |         // Same actual result must traverse postprocessing and displayed Canvas.
  29  |         await expect.poll(() => page.evaluate(id => window.__realSdkProbe.draws.some(d => d.id === id && d.alphaPixels > 0 && d.width === 512 && d.height === 512), result!.id)).toBe(true);
  30  |         for (const obj of result!.objects as Array<{ confidence: number; bbox: { x: number; y: number; width: number; height: number } }>) {
  31  |           expect(Number.isFinite(obj.confidence) && obj.confidence >= 0 && obj.confidence <= 1).toBe(true);
  32  |           expect(Object.values(obj.bbox).every(Number.isFinite)).toBe(true);
  33  |           expect(obj.bbox.x).toBeGreaterThanOrEqual(0); expect(obj.bbox.y).toBeGreaterThanOrEqual(0);
  34  |           expect(obj.bbox.width).toBeGreaterThan(0); expect(obj.bbox.width).toBeLessThanOrEqual(1);
  35  |           expect(obj.bbox.height).toBeGreaterThan(0); expect(obj.bbox.height).toBeLessThanOrEqual(1);
  36  |         }
  37  |         if (model === 'mediapipe') {
  38  |           for (const raw of raws) for (const det of raw.detections ?? []) {
  39  |             expect(det.bbox && Object.values(det.bbox).every(Number.isFinite) && det.bbox.width > 0 && det.bbox.height > 0).toBe(true);
  40  |             expect(det.categories.every(c => Number.isFinite(c.score) && c.score >= 0 && c.score <= 1)).toBe(true);
  41  |           }
  42  |           expect(raws.some(r => r.detections?.some((d: { categories: { label: string; score: number }[] }) => d.categories.some(c => c.label === 'cup' && Number.isFinite(c.score) && c.score >= 0.35)))).toBe(true);
  43  |         } else {
  44  |           const masks = raws.flatMap(r => r.masks ?? []);
  45  |           expect(masks.length).toBeGreaterThan(0);
  46  |           expect(await page.evaluate(() => window.__realSdkProbe.draws.some(d => d.maskDraws > 0 && d.alphaPixels > 0))).toBe(true);
  47  |           for (const mask of masks) {
  48  |             expect(mask.width > 0 && mask.height > 0 && mask.length === mask.width * mask.height && mask.finite).toBe(true);
  49  |             expect(mask.min).toBeGreaterThanOrEqual(0); expect(mask.max).toBeLessThanOrEqual(1);
  50  |           }
  51  |           expect(masks.some(m => m.personRegion > 0.5 && m.personRegion > m.backgroundRegion + 0.2 && m.foregroundFraction > 0.05 && m.foregroundFraction < 0.95)).toBe(true);
  52  |         }
  53  |         await expect.poll(() => page.evaluate(() => window.__realSdkProbe.snapshots.some(s => (['sdk', 'postprocess', 'draw'] as const).every(stage => s.stages[stage].success.measured > 0)))).toBe(true);
  54  |         const metric = await page.evaluate(() => window.__realSdkProbe.snapshots.at(-1)!);
  55  |         if (input === 'HTMLVideoElement') { expect(metric.stages.latency.success.count).toBe(0); expect(metric.results.unbound).toBeGreaterThan(0); }
  56  |         else expect(metric.stages.latency.success.measured).toBeGreaterThan(0);
  57  |         const creations = await page.evaluate(() => window.__realSdkProbe.creates.length);
  58  |         // Observed reentrant cancellation follows a real SDK result, never a fake result.
  59  |         await page.evaluate(() => { window.__realSdkProbe.invalidateAfterNextSdk = true; });
  60  |         await expect.poll(() => page.evaluate(() => window.__realSdkProbe.processed.some(r => r.status === 'not-ready'))).toBe(true);
  61  |         const stale = await page.evaluate(() => window.__realSdkProbe.processed.filter(r => r.status === 'not-ready').map(r => r.id));
  62  |         expect(await page.evaluate(ids => window.__realSdkProbe.draws.some(d => ids.includes(d.id)), stale)).toBe(false);
  63  |         await page.getByRole('banner').getByRole('button', { name: '停止', exact: true }).click();
  64  |         await expect.poll(() => page.evaluate(() => window.__realCamera.liveTracks())).toBe(0);
  65  |         if (input === 'VideoFrame') expect(await page.evaluate(() => window.__realCamera.framesCreated - window.__realCamera.framesClosed)).toBe(0);
  66  |         await page.getByRole('banner').getByRole('button', { name: 'カメラ開始', exact: true }).click();
  67  |         await expect.poll(() => page.evaluate(() => window.__realCamera.requests)).toBe(2);
  68  |         expect(await page.evaluate(() => window.__realSdkProbe.creates.length)).toBe(creations);
  69  |         // Both textured background and empty controls; allow existing 2-frame retention.
  70  |         for (const scene of ['background', 'empty']) {
  71  |           const boundary = await page.evaluate(scene => {
  72  |             const probe = window.__realSdkProbe;
  73  |             const latest = probe.processed.at(-1)!;
  74  |             window.__realCamera.scene = scene;
  75  |             return { afterCallId: probe.calls, afterResultId: latest.id, model: latest.model, input: latest.input, requestId: latest.requestId,
  76  |               stamp: { scene, revision: window.__realCamera.revision + 1, stream: window.__realCamera.requests } };
  77  |           }, scene);
  78  |           await expect.poll(async () => {
  79  |             const result = await page.evaluate(({ boundary, expected }) => window.__realSdkProbe.negativeCheck(boundary, expected), { boundary, expected });
  80  |             expect(result.status, result.reason).not.toBe('fail');
  81  |             return result.status;
  82  |           }).toBe('pass');
  83  |         }
  84  |         const other = model === 'mediapipe' ? 'selfie-segmenter' : 'mediapipe';
  85  |         await page.getByRole('banner').getByRole('combobox').selectOption(other);
  86  |         await ready(page);
  87  |         await expect.poll(() => page.evaluate(other => window.__realSdkProbe.processed.some(r => r.model === other && r.status === 'ready'), other)).toBe(true);
  88  |         expect(await page.evaluate(() => window.__realSdkProbe.creates.length)).toBe(creations + 1);
  89  |         expect(errors).toEqual([]);
  90  |         await page.screenshot({ path: testInfo.outputPath('app.png') });
  91  |       } finally {
  92  |         await release(page);
  93  |         const evidence = await page.evaluate(() => ({ probe: window.__realSdkProbe, camera: { ...window.__realCamera, liveTracks: window.__realCamera.liveTracks() } }));
  94  |         await writeFile(testInfo.outputPath('evidence.json'), JSON.stringify({ runtime: await runtimeEvidence(page), requests, evidence, errors }, null, 2));
  95  |         expect(evidence.camera.liveTracks).toBe(0); expect(evidence.camera.doubleCloses).toBe(0);
  96  |         expect(evidence.probe.creates.every(c => c.delegate === 'GPU')).toBe(true);
  97  |         expect(evidence.probe.closes).toBe(evidence.probe.creates.filter(c => !c.error).length);
  98  |       }
  99  |     });
  100 |   }
  101 | }
  102 | for (const model of ['mediapipe', 'selfie-segmenter'] as const) {
  103 |   test(`asset diagnostic ${model}`, async ({ context, page }, testInfo) => {
  104 |     await installCamera(context, 'VideoFrame', 'astronaut.png');
  105 |     const requests = await routeAssets(context, true);
  106 |     const errors: string[] = []; page.on('pageerror', e => errors.push(e.message));
  107 |     try {
  108 |       await page.goto('/');
  109 |       if (model === 'mediapipe') await page.getByRole('banner').getByRole('combobox').selectOption(model);
  110 |       await expect(page.getByRole('alert')).toContainText('モデルの生成に失敗しました。', { timeout: 30_000 });
  111 |       await expect.poll(() => page.evaluate(model => window.__realSdkProbe.creates.some(c => c.model === model && !!c.error), model)).toBe(true);
> 112 |       expect(requests.some(r => r.url.includes(model === 'mediapipe' ? 'efficientdet_lite0.tflite' : 'selfie_segmenter.tflite') && r.status === 'controlled HTTP503')).toBe(true);
      |                                                                                                                                                                        ^ Error: expect(received).toBe(expected) // Object.is equality
  113 |       const modelAsset = manifest.assets.find(asset => asset.file === (model === 'mediapipe' ? 'efficientdet_lite0.tflite' : 'selfie_segmenter.tflite'))!;
  114 |       expect(await page.evaluate(model => window.__realSdkProbe.creates.find(c => c.model === model && c.error)?.error, model)).toBe(`Error: Failed to fetch model: ${modelAsset.url} (503)`);
  115 |       expect(await page.evaluate(() => window.__realSdkProbe.calls)).toBe(0);
  116 |       expect(errors).toEqual([]);
  117 |       await expect(page.locator('video')).toHaveCount(1);
  118 |       await page.screenshot({ path: testInfo.outputPath('diagnostic.png') });
  119 |     } finally {
  120 |       await release(page);
  121 |       await writeFile(testInfo.outputPath('diagnostic.json'), JSON.stringify({ model, requests, runtime: await runtimeEvidence(page), observation: await page.evaluate(() => window.__realSdkProbe), errors }, null, 2));
  122 |     }
  123 |   });
  124 | }
  125 | 
```