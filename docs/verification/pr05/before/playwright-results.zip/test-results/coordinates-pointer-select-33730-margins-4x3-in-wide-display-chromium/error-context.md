# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: coordinates.spec.ts >> pointer selects displayed object and excludes margins: 4x3 in wide display
- Location: e2e/coordinates.spec.ts:16:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "「犬」、信頼度90%",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]: VisionStudio AI
    - generic [ref=e12]:
      - generic [ref=e13]:
        - generic [ref=e14]: "モデル:"
        - combobox "モデル" [ref=e15] [cursor=pointer]:
          - option "Selfie Segmenter"
          - option "EfficientDet-Lite0" [selected]
          - option "YOLO-seg（未実装・選択不可）" [disabled]
          - option "SegFormer（未実装・選択不可）" [disabled]
      - generic "バックエンド状態" [ref=e20]: GPU delegate 指定・初期化済み（GPU実動作は未計測）
    - generic [ref=e21]:
      - button "音声読み上げ OFF (クリックで有効化)" [ref=e22]
      - button "仕様" [ref=e27]
      - button "停止" [ref=e32]
  - status [ref=e39]: モデル準備完了（カメラの準備・推論成功とは別です）
  - main [ref=e40]:
    - generic [ref=e42]:
      - generic [ref=e44] [cursor=pointer]
      - button "インカメラ" [ref=e45]
      - generic:
        - text: EfficientDet-Lite0カメラ映像を取得しました計測中
        - generic "推論FPS": "推論: 未計測"
        - generic "描画FPS": "描画: 55.3 FPS"
        - generic "フレーム処理時間": "フレーム処理: 62.7 ms"
      - generic: 物体をタップすると日本語で発話
    - generic [ref=e54]:
      - generic [ref=e55]:
        - button "認識物体 (1)" [ref=e56]
        - button "音声・設定" [ref=e62]
      - generic [ref=e67]:
        - generic [ref=e68]:
          - generic [ref=e69]: 認識結果 (1件)
          - generic [ref=e70]: タップで個別発話
        - generic [ref=e72] [cursor=pointer]:
          - generic [ref=e75]:
            - generic [ref=e76]:
              - generic [ref=e77]: 犬
              - generic [ref=e78]: (dog)
            - generic [ref=e79]:
              - generic [ref=e80]: 動物
              - generic [ref=e81]: ·
              - generic [ref=e82]: 90%
          - button "読み上げる" [ref=e83]
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test';
  2   | 
  3   | interface CoordinateProbe {
  4   |   requests: number;
  5   |   speech: string[];
  6   |   arcs: number[][];
  7   |   dispose: () => void;
  8   | }
  9   | declare global { interface Window { coordinateProbe: CoordinateProbe } }
  10  | test.use({ baseURL: 'http://127.0.0.1:4174', deviceScaleFactor: 2 });
  11  | 
  12  | for (const scenario of [
  13  |   { name: '4x3 in wide display', width: 640, height: 480, viewport: { width: 1600, height: 550 } },
  14  |   { name: '16x9 in narrow display', width: 1280, height: 720, viewport: { width: 550, height: 900 } },
  15  | ]) {
  16  |   test(`pointer selects displayed object and excludes margins: ${scenario.name}`, async ({ context, page }, testInfo) => {
  17  |     await page.setViewportSize(scenario.viewport);
  18  |     await context.route('**/*', route => new URL(route.request().url()).origin === 'http://127.0.0.1:4174' ? route.continue() : route.abort());
  19  |     await context.addInitScript(({ width, height }) => {
  20  |       const streams: MediaStream[] = [];
  21  |       const sources: HTMLCanvasElement[] = [];
  22  |       const probe: CoordinateProbe = window.coordinateProbe = { requests: 0, speech: [], arcs: [], dispose() { streams.forEach(s => s.getTracks().forEach(t => t.stop())); sources.length = 0; } };
  23  |       const arc = CanvasRenderingContext2D.prototype.arc;
  24  |       CanvasRenderingContext2D.prototype.arc = function(...args: Parameters<typeof arc>) { probe.arcs.push([args[0], args[1], args[2]]); if (probe.arcs.length > 20) probe.arcs.shift(); return arc.apply(this, args); };
  25  |       window.speechSynthesis.speak = utterance => { probe.speech.push(utterance.text); };
  26  |       Object.defineProperty(navigator, 'mediaDevices', { configurable: true, value: { getUserMedia: async () => {
  27  |         probe.requests++;
  28  |         const source = document.createElement('canvas'); source.width = width; source.height = height;
  29  |         const ctx = source.getContext('2d')!; ctx.fillStyle = '#18324f'; ctx.fillRect(0, 0, width, height);
  30  |         ctx.fillStyle = '#c7e6a4'; ctx.fillRect(64, 48, 128, 96);
  31  |         sources.push(source); // Keep the actual image alive for the whole test.
  32  |         const stream = source.captureStream(0); streams.push(stream); return stream;
  33  |       } } });
  34  |     }, scenario);
  35  |     await page.goto('/');
  36  |     try {
  37  |       await page.evaluate(() => { window.visionSdkProbe.observeInputs = true; });
  38  |       await page.getByRole('banner').getByRole('combobox', { name: 'モデル', exact: true }).selectOption('mediapipe');
  39  |       await expect(page.getByText('(dog)')).toBeVisible();
  40  |       const geometry = await page.evaluate(() => {
  41  |         const video = document.querySelector('video')!; const canvas = document.querySelector('canvas')!;
  42  |         const box = (element: Element) => { const r = element.getBoundingClientRect(); const s = getComputedStyle(element); return { left: r.left, top: r.top, width: r.width, height: r.height, objectFit: s.objectFit, objectPosition: s.objectPosition, transform: s.transform }; };
  43  |         const snapshot = document.createElement('canvas'); snapshot.width = video.videoWidth; snapshot.height = video.videoHeight;
  44  |         const ctx = snapshot.getContext('2d')!; ctx.drawImage(video, 0, 0);
  45  |         const input = window.visionSdkProbe.inputs.at(-1)!;
  46  |         const sample = (x: number, y: number) => input.pixels.slice((y * video.videoWidth + x) * 4, (y * video.videoWidth + x) * 4 + 4);
  47  |         const pixels = { videoBackground: Array.from(ctx.getImageData(0, 0, 1, 1).data), videoObject: Array.from(ctx.getImageData(100, 100, 1, 1).data),
  48  |           sdkBackground: sample(0, 0), sdkObject: sample(100, 100), sdkPixelLength: input.pixels.length, sdkSourceKind: input.sourceKind };
  49  |         return { pixels, video: box(video), canvas: box(canvas), intrinsic: [video.videoWidth, video.videoHeight], backing: [canvas.width, canvas.height], dpr: devicePixelRatio };
  50  |       });
  51  |       const scale = Math.min(geometry.video.width / scenario.width, geometry.video.height / scenario.height);
  52  |       const left = geometry.video.left + (geometry.video.width - scenario.width * scale) / 2;
  53  |       const top = geometry.video.top + (geometry.video.height - scenario.height * scale) / 2;
  54  |       const point = { x: left + 188 * scale, y: top + 138 * scale };
  55  |       const margin = scenario.width === 640
  56  |         ? { x: left - 2, y: top + 100 * scale }
  57  |         : { x: left + 100 * scale, y: top - 2 };
  58  |       expect(geometry.video.objectFit).toBe('contain'); expect(geometry.canvas.objectFit).toBe('contain');
  59  |       expect(geometry.video.objectPosition).toBe('50% 50%'); expect(geometry.canvas.objectPosition).toBe('50% 50%');
  60  |       expect(geometry.video.transform).toBe('none'); expect(geometry.backing).toEqual([scenario.width, scenario.height]);
  61  |       expect(margin.x).toBeGreaterThan(geometry.video.left); expect(margin.x).toBeLessThan(geometry.video.left + geometry.video.width);
  62  |       expect(margin.y).toBeGreaterThan(geometry.video.top); expect(margin.y).toBeLessThan(geometry.video.top + geometry.video.height);
  63  |       expect(Math.abs(geometry.video.width / geometry.video.height - scenario.width / scenario.height)).toBeGreaterThan(0.1);
  64  |       expect(geometry.pixels.sdkPixelLength).toBe(scenario.width * scenario.height * 4);
  65  |       for (const pixels of [geometry.pixels.videoBackground, geometry.pixels.sdkBackground]) {
  66  |         [24, 50, 79, 255].forEach((value, i) => expect(Math.abs(pixels[i] - value)).toBeLessThanOrEqual(2));
  67  |       }
  68  |       for (const pixels of [geometry.pixels.videoObject, geometry.pixels.sdkObject]) {
  69  |         [199, 230, 164, 255].forEach((value, i) => expect(Math.abs(pixels[i] - value)).toBeLessThanOrEqual(2));
  70  |       }
  71  |       const creates = await page.evaluate(() => window.visionSdkProbe.creates);
  72  |       await page.mouse.click(margin.x, margin.y);
  73  |       await page.waitForTimeout(100);
  74  |       const marginObservation = await page.evaluate(() => ({ speech: [...window.coordinateProbe.speech], arcs: [...window.coordinateProbe.arcs] }));
  75  |       await testInfo.attach('margin.png', { body: await page.screenshot(), contentType: 'image/png' });
  76  |       const group = page.locator('.group').filter({ has: page.getByText('(dog)') });
  77  |       const marginSelected = /border-blue-500\/80/.test(await group.getAttribute('class') ?? '');
  78  |       await page.mouse.click(point.x, point.y);
  79  |       await page.waitForTimeout(150);
  80  |       const observations = await page.evaluate(() => ({ speech: window.coordinateProbe.speech, arcs: window.coordinateProbe.arcs, requests: window.coordinateProbe.requests, creates: window.visionSdkProbe.creates }));
  81  |       const evidence = { scenario, geometry, content: { left, top, width: scenario.width * scale, height: scenario.height * scale }, point, margin, marginObservation, marginSelected, observations };
  82  |       console.log('coordinate observation', JSON.stringify(evidence));
  83  |       await testInfo.attach('geometry.json', { body: JSON.stringify(evidence, null, 2), contentType: 'application/json' });
  84  |       await testInfo.attach('display.png', { body: await page.screenshot(), contentType: 'image/png' });
> 85  |       expect(marginObservation.speech).toEqual([]); expect(marginObservation.arcs).toEqual([]); expect(marginSelected).toBe(false);
      |                                        ^ Error: expect(received).toEqual(expected) // deep equality
  86  |       await expect(group).toHaveClass(/border-blue-500\/80/);
  87  |       expect(observations.speech).toHaveLength(1);
  88  |       expect(observations.arcs.length).toBeGreaterThan(0);
  89  |       // Native MouseEvent coordinates can be quantized to a CSS pixel.
  90  |       expect(Math.abs(observations.arcs.at(-1)![0] - 188)).toBeLessThanOrEqual(1 / scale);
  91  |       expect(Math.abs(observations.arcs.at(-1)![1] - 138)).toBeLessThanOrEqual(1 / scale);
  92  |       expect(observations.requests).toBe(1); expect(observations.creates).toBe(creates);
  93  |       // Exercise a real responsive resize without camera or model replacement.
  94  |       await page.setViewportSize({ width: 900, height: 700 });
  95  |       const resized = await page.locator('video').boundingBox(); expect(resized).not.toBeNull();
  96  |       const nextScale = Math.min(resized!.width / scenario.width, resized!.height / scenario.height);
  97  |       await page.mouse.click(resized!.x + (resized!.width - scenario.width * nextScale) / 2 + 90 * nextScale,
  98  |         resized!.y + (resized!.height - scenario.height * nextScale) / 2 + 90 * nextScale);
  99  |       await expect.poll(() => page.evaluate(() => window.coordinateProbe.speech.length)).toBe(2);
  100 |       await expect.poll(() => page.evaluate(() => Math.abs((window.coordinateProbe.arcs.at(-1)?.[0] ?? -1) - 90))).toBeLessThanOrEqual(1 / nextScale);
  101 |       const ripple = await page.evaluate(() => window.coordinateProbe.arcs.at(-1)![0]);
  102 |       expect(Math.abs(ripple - 90)).toBeLessThanOrEqual(1 / nextScale);
  103 |       const afterResize = await page.evaluate(() => ({ arcs: window.coordinateProbe.arcs, requests: window.coordinateProbe.requests, creates: window.visionSdkProbe.creates }));
  104 |       expect(Math.abs(afterResize.arcs.at(-1)![1] - 90)).toBeLessThanOrEqual(1 / nextScale);
  105 |       expect(afterResize.requests).toBe(1); expect(afterResize.creates).toBe(creates);
  106 |       await testInfo.attach('resize.json', { body: JSON.stringify({ resized, nextScale, afterResize }, null, 2), contentType: 'application/json' });
  107 |     } finally { await page.evaluate(() => window.coordinateProbe.dispose()); }
  108 |   });
  109 | }
  110 | 
```