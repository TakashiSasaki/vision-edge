# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: coordinates.spec.ts >> pointer selects displayed object and excludes margins: 16x9 in narrow display
- Location: e2e/coordinates.spec.ts:16:3

# Error details

```
Error: expect(locator).toHaveClass(expected) failed

Locator: locator('.group').filter({ has: getByText('(dog)') })
Expected pattern: /border-blue-500\/80/
Received string:  "p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between group bg-slate-900/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900"
Timeout: 5000ms

Call log:
  - Expect "toHaveClass" locator('.group').filter({ has: getByText('(dog)') }) with timeout 5000ms
  - waiting for locator('.group').filter({ has: getByText('(dog)') })
    14 × locator resolved to <div class="p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between group bg-slate-900/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900">…</div>
       - unexpected value "p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between group bg-slate-900/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900"

```

```yaml
- text: 犬 (dog) 動物 · 90%
- button "読み上げる"
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test';
  2  | 
  3  | interface CoordinateProbe {
  4  |   requests: number;
  5  |   speech: string[];
  6  |   arcs: number[][];
  7  |   dispose: () => void;
  8  | }
  9  | declare global { interface Window { coordinateProbe: CoordinateProbe } }
  10 | test.use({ baseURL: 'http://127.0.0.1:4174' });
  11 | 
  12 | for (const scenario of [
  13 |   { name: '4x3 in wide display', width: 640, height: 480, viewport: { width: 1600, height: 650 } },
  14 |   { name: '16x9 in narrow display', width: 1280, height: 720, viewport: { width: 550, height: 900 } },
  15 | ]) {
  16 |   test(`pointer selects displayed object and excludes margins: ${scenario.name}`, async ({ context, page }, testInfo) => {
  17 |     await page.setViewportSize(scenario.viewport);
  18 |     await context.route('**/*', route => new URL(route.request().url()).origin === 'http://127.0.0.1:4174' ? route.continue() : route.abort());
  19 |     await context.addInitScript(({ width, height }) => {
  20 |       const streams: MediaStream[] = [];
  21 |       const probe: CoordinateProbe = window.coordinateProbe = { requests: 0, speech: [], arcs: [], dispose() { streams.forEach(s => s.getTracks().forEach(t => t.stop())); } };
  22 |       const arc = CanvasRenderingContext2D.prototype.arc;
  23 |       CanvasRenderingContext2D.prototype.arc = function(...args: Parameters<typeof arc>) { probe.arcs.push(args.slice(0, 3)); if (probe.arcs.length > 20) probe.arcs.shift(); return arc.apply(this, args); };
  24 |       window.speechSynthesis.speak = utterance => { probe.speech.push(utterance.text); };
  25 |       Object.defineProperty(navigator, 'mediaDevices', { configurable: true, value: { getUserMedia: async () => {
  26 |         probe.requests++;
  27 |         const source = document.createElement('canvas'); source.width = width; source.height = height;
  28 |         const ctx = source.getContext('2d')!; ctx.fillStyle = '#18324f'; ctx.fillRect(0, 0, width, height);
  29 |         ctx.fillStyle = '#c7e6a4'; ctx.fillRect(64, 48, 128, 96);
  30 |         const stream = source.captureStream(0); streams.push(stream); return stream;
  31 |       } } });
  32 |     }, scenario);
  33 |     await page.goto('/');
  34 |     try {
  35 |       await page.getByRole('banner').getByRole('combobox', { name: 'モデル', exact: true }).selectOption('mediapipe');
  36 |       await expect(page.getByText('(dog)')).toBeVisible();
  37 |       const geometry = await page.evaluate(() => {
  38 |         const video = document.querySelector('video')!; const canvas = document.querySelector('canvas')!;
  39 |         const box = (element: Element) => { const r = element.getBoundingClientRect(); const s = getComputedStyle(element); return { left: r.left, top: r.top, width: r.width, height: r.height, objectFit: s.objectFit, objectPosition: s.objectPosition, transform: s.transform }; };
  40 |         return { video: box(video), canvas: box(canvas), intrinsic: [video.videoWidth, video.videoHeight], backing: [canvas.width, canvas.height], dpr: devicePixelRatio };
  41 |       });
  42 |       const scale = Math.min(geometry.video.width / scenario.width, geometry.video.height / scenario.height);
  43 |       const left = geometry.video.left + (geometry.video.width - scenario.width * scale) / 2;
  44 |       const top = geometry.video.top + (geometry.video.height - scenario.height * scale) / 2;
  45 |       const point = { x: left + 188 * scale, y: top + 138 * scale };
  46 |       const margin = scenario.width === 640
  47 |         ? { x: left - 2, y: top + 100 * scale }
  48 |         : { x: left + 100 * scale, y: top - 2 };
  49 |       expect(geometry.video.objectFit).toBe('contain'); expect(geometry.canvas.objectFit).toBe('contain');
  50 |       expect(geometry.video.objectPosition).toBe('50% 50%'); expect(geometry.canvas.objectPosition).toBe('50% 50%');
  51 |       expect(geometry.video.transform).toBe('none'); expect(geometry.backing).toEqual([scenario.width, scenario.height]);
  52 |       expect(margin.x).toBeGreaterThan(geometry.video.left); expect(margin.x).toBeLessThan(geometry.video.left + geometry.video.width);
  53 |       expect(margin.y).toBeGreaterThan(geometry.video.top); expect(margin.y).toBeLessThan(geometry.video.top + geometry.video.height);
  54 |       expect(Math.abs(geometry.video.width / geometry.video.height - scenario.width / scenario.height)).toBeGreaterThan(0.1);
  55 |       const creates = await page.evaluate(() => window.visionSdkProbe.creates);
  56 |       await page.mouse.click(margin.x, margin.y);
  57 |       await page.waitForTimeout(100);
  58 |       expect(await page.evaluate(() => window.coordinateProbe.speech)).toEqual([]);
  59 |       expect(await page.evaluate(() => window.coordinateProbe.arcs)).toEqual([]);
  60 |       const group = page.locator('.group').filter({ has: page.getByText('(dog)') });
  61 |       await expect(group).not.toHaveClass(/border-blue-500\/80/);
  62 |       await page.mouse.click(point.x, point.y);
  63 |       await page.waitForTimeout(150);
  64 |       const observations = await page.evaluate(() => ({ speech: window.coordinateProbe.speech, arcs: window.coordinateProbe.arcs, requests: window.coordinateProbe.requests, creates: window.visionSdkProbe.creates }));
  65 |       const evidence = { scenario, geometry, content: { left, top, width: scenario.width * scale, height: scenario.height * scale }, point, margin, observations };
  66 |       console.log('coordinate observation', JSON.stringify(evidence));
  67 |       await testInfo.attach('geometry.json', { body: JSON.stringify(evidence, null, 2), contentType: 'application/json' });
  68 |       await testInfo.attach('display.png', { body: await page.screenshot(), contentType: 'image/png' });
> 69 |       await expect(group).toHaveClass(/border-blue-500\/80/);
     |                           ^ Error: expect(locator).toHaveClass(expected) failed
  70 |       expect(observations.speech).toHaveLength(1);
  71 |       expect(observations.arcs.length).toBeGreaterThan(0);
  72 |       // Native MouseEvent coordinates can be quantized to a CSS pixel.
  73 |       expect(Math.abs(observations.arcs.at(-1)![0] - 188)).toBeLessThanOrEqual(1 / scale);
  74 |       expect(Math.abs(observations.arcs.at(-1)![1] - 138)).toBeLessThanOrEqual(1 / scale);
  75 |       expect(observations.requests).toBe(1); expect(observations.creates).toBe(creates);
  76 |     } finally { await page.evaluate(() => window.coordinateProbe.dispose()); }
  77 |   });
  78 | }
  79 | 
```