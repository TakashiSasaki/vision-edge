# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: frame-identity.spec.ts >> F01 actual canvas/engine consumes one decoded image after delayed execution (fallback)
- Location: e2e/frame-identity.spec.ts:136:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByLabel('フレーム処理時間')
Expected pattern: /\d+\.\d+ ms/
Received string:  "フレーム処理: 未計測"
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByLabel('フレーム処理時間') with timeout 5000ms
  - waiting for getByLabel('フレーム処理時間')
    13 × locator resolved to <span class="ml-2" aria-label="フレーム処理時間">フレーム処理: 未計測</span>
       - unexpected value "フレーム処理: 未計測"

```

```yaml
- text: "フレーム処理: 未計測"
```

# Test source

```ts
  66  |       if (!probe.contend || probe.delayed === 0) return;
  67  |       const video = document.querySelector('video')!;
  68  |       const canvas = document.createElement('canvas'); canvas.width = 64; canvas.height = 64;
  69  |       const context = canvas.getContext('2d', { willReadFrequently: true })!;
  70  |       const image = new VideoFrame(video);
  71  |       try {
  72  |         context.drawImage(image, 0, 0);
  73  |         probe.reservedPixels = Array.from(context.getImageData(0, 0, 64, 64).data);
  74  |         probe.reservedImageTimestamp = image.timestamp;
  75  |       } finally { image.close(); }
  76  |       probe.reservedFrames = video.getVideoPlaybackQuality().totalVideoFrames;
  77  |       probe.contend = false; probe.blocked++;
  78  |       const end = performance.now() + 320;
  79  |       while (performance.now() < end) { /* Native decoding continues during main-thread contention. */ }
  80  |     };
  81  |     Object.defineProperty(HTMLVideoElement.prototype, 'requestVideoFrameCallback', { configurable: true, value: fallback ? undefined : function(this: HTMLVideoElement, callback: VideoFrameRequestCallback) {
  82  |       return nativeRvfc.call(this, (now, metadata) => {
  83  |         const deliver = () => { callback(now, metadata); contend(); };
  84  |         if (!releaseBeforeArrival(deliver)) deliver();
  85  |       });
  86  |     } });
  87  |     if (fallback) window.requestAnimationFrame = callback => nativeRaf(now => {
  88  |       const deliver = () => { callback(now); contend(); };
  89  |       if (!releaseBeforeArrival(deliver)) deliver();
  90  |     });
  91  |     HTMLMediaElement.prototype.play = function() {
  92  |       if (this instanceof HTMLVideoElement && this.srcObject instanceof MediaStream) {
  93  |         nativeRvfc.call(this, (_now, metadata) => { probe.first.push({ mediaTime: metadata.mediaTime, presentedFrames: metadata.presentedFrames }); });
  94  |         if (kind === 'still') {
  95  |           const track = this.srcObject.getVideoTracks()[0] as CanvasCaptureMediaStreamTrack;
  96  |           nativeTimeout(() => track.requestFrame(), 20);
  97  |           // Third scene: race a second presentation against the bootstrap timer.
  98  |           if (probe.requests === 3) nativeTimeout(() => probe.drawNext(), 60);
  99  |         }
  100 |       }
  101 |       return nativePlay.call(this);
  102 |     };
  103 |     Object.defineProperty(navigator, 'mediaDevices', { configurable: true, value: { getUserMedia: async () => {
  104 |       probe.requests++;
  105 |       const canvas = document.createElement('canvas'); canvas.width = 64; canvas.height = 64;
  106 |       const ctx = canvas.getContext('2d')!;
  107 |       ctx.fillStyle = '#154a73'; ctx.fillRect(0, 0, 64, 64);
  108 |       if (kind === 'still') {
  109 |         if (probe.requests === 3) probe.hold = true;
  110 |         const stream = canvas.captureStream(0);
  111 |         probe.drawNext = () => { ctx.fillStyle = '#d49227'; ctx.fillRect(0, 0, 64, 64); (stream.getVideoTracks()[0] as CanvasCaptureMediaStreamTrack).requestFrame(); };
  112 |         probe.streams.push(stream); return stream;
  113 |       }
  114 |       // Encode a changing clip in-browser, then let the native decoder progress
  115 |       // independently of the blocked JS thread. No ffmpeg or downloaded fixture.
  116 |       const recordingStream = canvas.captureStream(20); probe.streams.push(recordingStream);
  117 |       const recorder = new MediaRecorder(recordingStream, { mimeType: 'video/webm;codecs=vp8' });
  118 |       const chunks: BlobPart[] = [];
  119 |       recorder.ondataavailable = event => { chunks.push(event.data); };
  120 |       const recorded = new Promise<void>(resolve => { recorder.onstop = () => resolve(); });
  121 |       recorder.start();
  122 |       for (let frame = 0; frame < 30; frame++) {
  123 |         ctx.fillStyle = `rgb(${frame * 7},${255 - frame * 5},${frame * 3})`; ctx.fillRect(0, 0, 64, 64);
  124 |         await new Promise<void>(resolve => nativeTimeout(resolve, 50));
  125 |       }
  126 |       recorder.stop(); await recorded; recordingStream.getTracks().forEach(track => track.stop());
  127 |       const source = document.createElement('video'); source.muted = true; source.playsInline = true; source.loop = true;
  128 |       source.src = URL.createObjectURL(new Blob(chunks, { type: recorder.mimeType })); urls.push(source.src); probe.source = source;
  129 |       await nativePlay.call(source);
  130 |       const stream = (source as HTMLVideoElement & { captureStream: () => MediaStream }).captureStream(); probe.streams.push(stream); return stream;
  131 |     } } });
  132 |   }, { fallback, kind });
  133 | }
  134 | 
  135 | for (const fallback of [false, true]) {
  136 |   test(`F01 actual canvas/engine consumes one decoded image after delayed execution (${fallback ? 'fallback' : 'rVFC'})`, async ({ context, page }, testInfo) => {
  137 |     await installProbe(context, fallback, 'decoded');
  138 |     const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  139 |     await page.goto('/');
  140 |     try {
  141 |       await expect.poll(() => page.evaluate(() => window.nativeFrameProbe.first.length)).toBe(1);
  142 |       await expect(page.getByLabel('カメラ状態')).toHaveText('カメラ映像を取得しました');
  143 |       await page.evaluate(() => {
  144 |         window.visionSdkProbe.observeInputs = true;
  145 |         window.visionSdkProbe.afterInput = video => { video.pause(); window.nativeFrameProbe.source!.pause(); };
  146 |         window.nativeFrameProbe.hold = true; window.nativeFrameProbe.contend = true;
  147 |         window.nativeFrameProbe.releaseModel();
  148 |       });
  149 |       await expect.poll(() => page.evaluate(() => window.visionSdkProbe.calls)).toBeGreaterThanOrEqual(1);
  150 |       await page.waitForTimeout(500);
  151 |       const result = await page.evaluate(() => ({ inputs: window.visionSdkProbe.inputs, calls: window.visionSdkProbe.calls,
  152 |         reservedImageTimestamp: window.nativeFrameProbe.reservedImageTimestamp, reservedPixels: window.nativeFrameProbe.reservedPixels, reservedFrames: window.nativeFrameProbe.reservedFrames, delayed: window.nativeFrameProbe.delayed, blocked: window.nativeFrameProbe.blocked, requests: window.nativeFrameProbe.requests }));
  153 |       const evidence = { ...result, samePixelsAcrossInputs: result.inputs.slice(1).map(input => input.pixels.every((value, i) => value === result.inputs[0].pixels[i])), reservedPixels: undefined, reservedPixelSha256: createHash('sha256').update(Buffer.from(result.reservedPixels)).digest('hex'), inputs: result.inputs.map(input => ({ sourceKind: input.sourceKind, time: input.time,
  154 |         qualityFrames: input.qualityFrames, pixelSha256: createHash('sha256').update(Buffer.from(input.pixels)).digest('hex') })) };
  155 |       console.log('F01 native input', JSON.stringify(evidence));
  156 |       await testInfo.attach('consumed-native-input.json', { body: JSON.stringify(evidence, null, 2), contentType: 'application/json' });
  157 |       expect(result.delayed).toBe(1); expect(result.blocked).toBe(1);
  158 |       expect(result.calls).toBe(1); expect(result.inputs).toHaveLength(1);
  159 |       expect(result.inputs[0].pixels).toHaveLength(64 * 64 * 4);
  160 |       expect(result.inputs[0].sourceKind).toBe('video-frame');
  161 |       expect(result.inputs[0].time! * 1000000).toBeGreaterThan(result.reservedImageTimestamp);
  162 |       expect(result.inputs[0].qualityFrames).toBeGreaterThanOrEqual(result.reservedFrames);
  163 |       expect(result.inputs[0].pixels.every((value, i) => value === result.reservedPixels[i])).toBe(false);
  164 |       expect(result.requests).toBe(1);
  165 |       await expect(page.getByLabel('推論FPS')).toHaveText('推論: 未計測');
> 166 |       await expect(page.getByLabel('フレーム処理時間')).toContainText(/\d+\.\d+ ms/);
      |                                                 ^ Error: expect(locator).toContainText(expected) failed
  167 |       expect(errors).toEqual([]);
  168 |     } finally { await page.evaluate(() => window.nativeFrameProbe.dispose()); }
  169 |   });
  170 |   test(`F02 pre-presented first frame, equal-time restart and bootstrap/arrival race (${fallback ? 'fallback' : 'rVFC'})`, async ({ context, page }, testInfo) => {
  171 |     await installProbe(context, fallback, 'still');
  172 |     await page.goto('/');
  173 |     try {
  174 |       await expect.poll(() => page.evaluate(() => window.nativeFrameProbe.first.length)).toBe(1);
  175 |       await expect(page.getByLabel('カメラ状態')).toHaveText('カメラ映像を取得しました');
  176 |       expect(await page.evaluate(() => window.visionSdkProbe.calls)).toBe(0);
  177 |       await page.evaluate(() => { window.visionSdkProbe.observeInputs = true; window.nativeFrameProbe.releaseModel(); });
  178 |       await expect.poll(() => page.evaluate(() => window.visionSdkProbe.calls)).toBe(1);
  179 |       await page.waitForTimeout(400); expect(await page.evaluate(() => window.visionSdkProbe.calls)).toBe(1);
  180 |       const creates = await page.evaluate(() => window.visionSdkProbe.creates);
  181 |       for (const session of [2, 3]) {
  182 |         await page.getByRole('banner').getByRole('button', { name: '停止', exact: true }).click();
  183 |         await page.getByRole('banner').getByRole('button', { name: 'カメラ開始', exact: true }).click();
  184 |         await expect.poll(() => page.evaluate(() => window.visionSdkProbe.calls)).toBe(session);
  185 |         await page.waitForTimeout(400); expect(await page.evaluate(() => window.visionSdkProbe.calls)).toBe(session);
  186 |       }
  187 |       const result = await page.evaluate(() => ({ inputs: window.visionSdkProbe.inputs.map(input => ({ time: input.time, qualityFrames: input.qualityFrames })),
  188 |         first: window.nativeFrameProbe.first, creates: window.visionSdkProbe.creates, requests: window.nativeFrameProbe.requests, delayed: window.nativeFrameProbe.delayed }));
  189 |       // currentTime is a running playhead; mediaTime identifies the source's
  190 |       // first image and is zero again in the new camera session.
  191 |       expect(result.first.slice(0, 2).map(first => first.mediaTime)).toEqual([0, 0]);
  192 |       expect(result.inputs[2].qualityFrames).toBeGreaterThanOrEqual(2);
  193 |       expect(result.creates).toBe(creates); expect(result.requests).toBe(3); expect(result.delayed).toBe(1);
  194 |       await expect(page.getByLabel('推論FPS')).toHaveText('推論: 未計測');
  195 |       console.log('F02 native scenes', JSON.stringify(result));
  196 |       await testInfo.attach('first-frame-scenes.json', { body: JSON.stringify(result, null, 2), contentType: 'application/json' });
  197 |     } finally { await page.evaluate(() => window.nativeFrameProbe.dispose()); }
  198 |   });
  199 | }
  200 | 
```